//package Utility;
//import java.sql.*;
//import java.util.ArrayList;
//import Model.Customer;
///**
// *
// * @author HP USER
// */
//public class DatabaseConnector {
//   private static final String DB_URL = "jdbc:mysql://localhost:3305/insurancedb?useSSL=false";
//   private static final String DB_USERNAME = "root";
//   private static final String DB_PASSWORD = "my-secret-pw";
//   
//   public static void addCustomer(Customer c1) throws SQLException{
//       String query = "INSERT INTO Customer(id,fname,age,gender,phone,email,carMake,carModel,year,appointmentType,appointmentDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";     
//       try{
//           Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
//           PreparedStatement stmt = conn.prepareStatement(query);
//           stmt.setInt(1, c1.getId());
//           stmt.setString(2, c1.getFullname());
//           stmt.setString(3, c1.getAge());
//           stmt.setString(4, c1.getGender());
//           stmt.setString(5, c1.getPhone());
//           stmt.setString(6, c1.getEmail());
//           stmt.setString(7, c1.getCarmake());
//           stmt.setString(8, c1.getCarmodel());
//           stmt.setInt(9, (int) c1.getMakeyear());
//           stmt.setString(10, c1.getAppointType());
//           stmt.setDate(11, new java.sql.Date(c1.getDate().getTime()));
//
//           int rows = stmt.executeUpdate();
//           System.out.print("Rows inserted: "+rows);
//           conn.close();
//       }catch (SQLException sqle){
//           System.out.print("SQL Exception Occured");
//           System.out.print(sqle);
//       } catch (Exception ex){
//           System.out.print(ex);
//       }
//       
//   }
//   public static ArrayList<Customer> getCustomers(){
//       ArrayList <Customer> customers = new ArrayList();
//       String query = "SELECT * FROM Customer";
//       try{
//            Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery(query);
//            while(rs.next()){
//                Customer c1 = new Customer();                
//                c1.setId(rs.getInt("id"));
//                c1.setFullname(rs.getString("fname"));
//                c1.setAge(rs.getString("age"));
//                c1.setGender(rs.getString("gender"));
//                c1.setPhone(rs.getString("phone"));
//                c1.setEmail(rs.getString("email"));
//                c1.setCarmake(rs.getString("carMake"));
//                c1.setCarmodel(rs.getString("carModel"));
//                c1.setMakeyear(rs.getInt("year"));
//                c1.setAppointType(rs.getString("appointmentType"));
//                c1.setDate(rs.getDate("appointmentDate"));
//                customers.add(c1);
//          }
//            rs.close();
//            conn.close();
//          } catch (SQLException sqle){
//            System.out.print("SQL Exception Occured");
//            System.out.print(sqle);
//          } catch (Exception ex){
//            System.out.print(ex);
//          }
//            return customers;
//          }
//   public static void updateCustomer(Customer oldCustomer, Customer updatedCustomer){
//       String query = "UPDATE Customer SET fname = ?, age = ?, gender = ?, phone = ?, email = ?, carMake = ?, carModel = ?, year = ?,  appointmentType = ?, appointmentDate = ? WHERE id = ? ";
//       try{  
//            Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
//            PreparedStatement stmt = conn.prepareStatement(query);
//           stmt.setString(1, updatedCustomer.getFullname());
//           stmt.setString(2, updatedCustomer.getAge());
//           stmt.setString(3, updatedCustomer.getGender());
//           stmt.setString(4, updatedCustomer.getPhone());
//           stmt.setString(5, updatedCustomer.getEmail());
//           stmt.setString(6, updatedCustomer.getCarmake());
//           stmt.setString(7, updatedCustomer.getCarmodel());
//           stmt.setInt(8, updatedCustomer.getMakeyear());
//           stmt.setString(9, updatedCustomer.getAppointType());
//           stmt.setDate(10, new java.sql.Date(updatedCustomer.getDate().getTime()));
//           stmt.setInt(11, oldCustomer.getId());
//           stmt.executeUpdate();
//           
//             conn.close();
//          } catch (SQLException sqle){
//            System.out.print("SQL Exception Occured");
//            System.out.print(sqle);
//          } catch (Exception ex){
//            System.out.print(ex);
//          }
//   }
//   public static void deleteCustomer(Customer c1){
//       String query = "DELETE FROM Customer WHERE id = ? ;";
//               try{
//            Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
//            PreparedStatement stmt = conn.prepareStatement(query);
//            stmt.setInt(1, c1.getId());
//            int rows = stmt.executeUpdate();
//            System.out.println("Rows deleted: "+rows);
//            conn.close();
//          } catch (SQLException sqle){
//            System.out.print("SQL Exception Occured");
//            System.out.print(sqle);
//          } catch (Exception ex){
//            System.out.print(ex);
//          }
//   }
//}


package Utility;

import java.sql.*;
import java.util.ArrayList;
import Model.Customer;

public class DatabaseConnector {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/insurancedb?useSSL=true";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "my-secret-pw";

    public static void addCustomer(Customer c1) {
        String query = "INSERT INTO Customer(id, fname, age, gender, phone, email, carMake, carModel, year, appointmentType, appointmentDate) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, c1.getId());
            stmt.setString(2, c1.getFullname());
            stmt.setString(3, c1.getAge());
            stmt.setString(4, c1.getGender());
            stmt.setString(5, c1.getPhone());
            stmt.setString(6, c1.getEmail());
            stmt.setString(7, c1.getCarmake());
            stmt.setString(8, c1.getCarmodel());
            stmt.setInt(9, c1.getMakeyear());
            stmt.setString(10, c1.getAppointType());
            stmt.setDate(11, new java.sql.Date(c1.getDate().getTime()));

            int rows = stmt.executeUpdate();
            System.out.println("Rows inserted: " + rows);
        } catch (SQLException sqle) {
            System.err.println("SQL Exception Occurred: " + sqle.getMessage());
        }
    }

    public static ArrayList<Customer> getCustomers() {
        ArrayList<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customer";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Customer c1 = new Customer();
                c1.setId(rs.getInt("id"));
                c1.setFullname(rs.getString("fname"));
                c1.setAge(rs.getString("age"));
                c1.setGender(rs.getString("gender"));
                c1.setPhone(rs.getString("phone"));
                c1.setEmail(rs.getString("email"));
                c1.setCarmake(rs.getString("carMake"));
                c1.setCarmodel(rs.getString("carModel"));
                c1.setMakeyear(rs.getInt("year"));
                c1.setAppointType(rs.getString("appointmentType"));
                c1.setDate(rs.getDate("appointmentDate"));
                customers.add(c1);
            }
        } catch (SQLException sqle) {
            System.err.println("SQL Exception Occurred: " + sqle.getMessage());
        }
        return customers;
    }

    public static void updateCustomer(Customer oldCustomer, Customer updatedCustomer) {
        String query = "UPDATE Customer SET fname = ?, age = ?, gender = ?, phone = ?, email = ?, carMake = ?, carModel = ?, year = ?, " +
                       "appointmentType = ?, appointmentDate = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, updatedCustomer.getFullname());
            stmt.setString(2, updatedCustomer.getAge());
            stmt.setString(3, updatedCustomer.getGender());
            stmt.setString(4, updatedCustomer.getPhone());
            stmt.setString(5, updatedCustomer.getEmail());
            stmt.setString(6, updatedCustomer.getCarmake());
            stmt.setString(7, updatedCustomer.getCarmodel());
            stmt.setInt(8, updatedCustomer.getMakeyear());
            stmt.setString(9, updatedCustomer.getAppointType());
            stmt.setDate(10, new java.sql.Date(updatedCustomer.getDate().getTime()));
            stmt.setInt(11, oldCustomer.getId());

            int rows = stmt.executeUpdate();
           
            System.out.println("Rows updated: " + rows);
        } catch (SQLException sqle) {
            System.err.println("SQL Exception Occurred: " + sqle.getMessage());
        }
    }

    public static void deleteCustomer(Customer c1) {
        String query = "DELETE FROM Customer WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, c1.getId());
            int rows = stmt.executeUpdate();
            System.out.println("Rows deleted: " + rows);
        } catch (SQLException sqle) {
            System.err.println("SQL Exception Occurred: " + sqle.getMessage());
        }
    }
}